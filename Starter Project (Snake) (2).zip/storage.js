// ================= STORAGE & SESSION MANAGEMENT =================
let currentActiveMode = 'chat'; // Track current mode (chat, research, studio)

function loadAllSessions() {
    const saved = localStorage.getItem("LifeTwist_all_sessions");
    if (saved) {
        try {
            allSessions = JSON.parse(saved);
        } catch(e) {
            allSessions = [];
        }
    }
    
    allSessions = allSessions.filter(s => s.messages && s.messages.length > 0);
    
    // REQUIREMENT 1: Refresh ya app open hone par hamesha naya fresh chat start hoga
    startFreshUnsavedSession();
}

function startFreshUnsavedSession() {
    currentSessionId = 'temp_' + Date.now();
    clearScreenAndRender();
}

function saveAllSessions() {
    if (isPrivateMode) return;

    // Ensure session has the current active mode tagged before saving
    let currentSession = allSessions.find(s => s.id === currentSessionId);
    if (currentSession && (!currentSession.mode)) {
        currentSession.mode = currentActiveMode;
    }

    const validSessions = allSessions.filter(s => s.messages && s.messages.length > 0);
    localStorage.setItem("LifeTwist_all_sessions", JSON.stringify(validSessions));
    renderSidebarList();
}

function createNewSession(openDrawer = true) {
    if (isPrivateMode) {
        togglePrivateMode(false);
    }
    allSessions = allSessions.filter(s => s.messages && s.messages.length > 0);
    startFreshUnsavedSession();
    if (openDrawer) {
        toggleSidebar(false);
    }
}

function switchSession(sessionId) {
    if (isPrivateMode) {
        togglePrivateMode(false);
    }
    currentSessionId = sessionId;
    clearScreenAndRender();
    toggleSidebar(false);
}

function getCurrentSession() {
    if (isPrivateMode) {
        return privateSession;
    }
    let session = allSessions.find(s => s.id === currentSessionId);
    if (!session) {
        session = {
            id: currentSessionId,
            title: "New Chat",
            mode: currentActiveMode,
            messages: []
        };
        allSessions.push(session);
    }
    return session;
}

function togglePrivateMode(forceState = null) {
    const privateBtn = document.getElementById("privateBtn");
    
    if (forceState !== null) {
        isPrivateMode = forceState;
    } else {
        isPrivateMode = !isPrivateMode;
    }

    if (isPrivateMode) {
        privateSession.messages = [];
        if (privateBtn) privateBtn.classList.add("active");
    } else {
        privateSession.messages = [];
        if (privateBtn) privateBtn.classList.remove("active");
    }

    clearScreenAndRender();
}

// Function to handle mode switching from header/sidebar (Ab yeh independent hai)
function setStorageMode(mode) {
    currentActiveMode = mode;
    // Tab aur storage ka connection todne ke liye yahan se loadAllSessions aur clearScreen hata diya hai
    renderSidebarList();
}
