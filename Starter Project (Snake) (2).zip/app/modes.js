function switchAppMode(mode) {
    currentMode = mode;
    currentHistoryTab = mode;
    
    if (typeof setStorageMode === 'function') {
        setStorageMode(mode);
    } else {
        currentActiveMode = mode;
        loadAllSessions();
        clearScreenAndRender();
    }
    
    const chatBtn = document.getElementById("tabChatBtn");
    const researchBtn = document.getElementById("tabResearchBtn");
    const studioBtn = document.getElementById("tabStudioBtn");
    
    if (chatBtn) chatBtn.classList.remove("active");
    if (researchBtn) researchBtn.classList.remove("active");
    if (studioBtn) studioBtn.classList.remove("active");
    
    if (mode === 'chat' && chatBtn) chatBtn.classList.add("active");
    if (mode === 'research' && researchBtn) researchBtn.classList.add("active");
    if (mode === 'studio' && studioBtn) studioBtn.classList.add("active");
    
    const histChat = document.getElementById("histTabChat");
    const histResearch = document.getElementById("histTabResearch");
    const histStudio = document.getElementById("histTabStudio");
    
    if (histChat) histChat.classList.remove("active");
    if (histResearch) histResearch.classList.remove("active");
    if (histStudio) histStudio.classList.remove("active");
    
    if (mode === 'chat' && histChat) histChat.classList.add("active");
    if (mode === 'research' && histResearch) histResearch.classList.add("active");
    if (mode === 'studio' && histStudio) histStudio.classList.add("active");
    
    const userInput = document.getElementById("userInput");
    if (userInput) {
        if (mode === 'research') {
            userInput.placeholder = "Wikipedia & Deep Research se poochho...";
        } else if (mode === 'studio') {
            userInput.placeholder = "Studio Mode: Smart Study & Tutor se poochho...";
        } else {
            userInput.placeholder = "Ask LifeTwist anything...";
        }
    }
    
    renderSidebarList();
}

function switchHeaderMode(mode) { switchAppMode(mode); }
function switchHistoryTab(tab) { switchAppMode(tab); }
